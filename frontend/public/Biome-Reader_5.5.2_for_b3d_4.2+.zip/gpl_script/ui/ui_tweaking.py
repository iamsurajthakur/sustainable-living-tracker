"""
• Script License: 

    This python script file is licensed under GPL 3.0
    
    This program is free software; you can redistribute it and/or modify it under 
    the terms of the GNU General Public License as published by the Free Software
    Foundation; either version 3 of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
    without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
    See the GNU General Public License for more details.
    
    See full license on 'https://www.gnu.org/licenses/gpl-3.0.en.html#license-text'

• Additonal Information: 

    The components in this archive are a mere aggregation of independent works. 
    The GPL-licensed scripts included here serve solely as a control and/or interface for 
    the Geo-Scatter geometry-node assets.

    The content located in the 'PluginFolder/non_gpl/' directory is NOT licensed under 
    the GPL. For details, please refer to the LICENSES.txt file within this folder.

    The non-GPL components and assets can function fully without the scripts and vice versa. 
    They do not form a derivative work, and are distributed together for user convenience.

    Redistribution, modification, or unauthorized use of the content in the 'non_gpl' folder,
    including .blend files or image files, is prohibited without prior written consent 
    from BD3D DIGITAL DESIGN, SLU.
        
• Trademark Information:

    Geo-Scatter® name & logo is a trademark or registered trademark of “BD3D DIGITAL DESIGN, SLU” 
    in the U.S. and/or European Union and/or other countries. We reserve all rights to this trademark. 
    For further details, please review our trademark and logo policies at “www.geoscatter.com/legal”. The 
    use of our brand name, logo, or marketing materials to distribute content through any non-official
    channels not listed on “www.geoscatter.com/download” is strictly prohibited. Such unauthorized use 
    falsely implies endorsement or affiliation with third-party activities, which has never been granted. We 
    reserve all rights to protect our brand integrity & prevent any associations with unapproved third parties.
    You are not permitted to use our brand to promote your unapproved activities in a way that suggests official
    endorsement or affiliation. As a reminder, the GPL license explicitly excludes brand names from the freedom,
    our trademark rights remain distinct and enforceable under trademark laws.

"""
# A product of “BD3D DIGITAL DESIGN, SLU”
# Authors:
# (c) 2024 Dorian Borremans

#####################################################################################################
#
# ooooo     ooo ooooo      ooooooooooooo                                      oooo         o8o
# `888'     `8' `888'      8'   888   `8                                      `888         `"'
#  888       8   888            888      oooo oooo    ooo  .ooooo.   .oooo.    888  oooo  oooo  ooo. .oo.    .oooooooo
#  888       8   888            888       `88. `88.  .8'  d88' `88b `P  )88b   888 .8P'   `888  `888P"Y88b  888' `88b
#  888       8   888            888        `88..]88..8'   888ooo888  .oP"888   888888.     888   888   888  888   888
#  `88.    .8'   888            888         `888'`888'    888    .o d8(  888   888 `88b.   888   888   888  `88bod8P'
#    `YbodP'    o888o          o888o         `8'  `8'     `Y8bod8P' `Y888""8o o888o o888o o888o o888o o888o `8oooooo.
#                                                                                                           d"     YD
#####################################################################################################       "Y88888P'


import bpy

from .. resources.icons import cust_icon
from .. translations import translate

from .. utils.str_utils import word_wrap, is_attr_surfs_shared
from .. utils.math_utils import count_repr

from .. scattering.texture_datablock import draw_texture_datablock

from . import ui_templates
from . ui_emitter_select import emitter_header

#TIP: for icons use 'https://ui.blender.org/icons'

# oooooooooooo                                       .    o8o
# `888'     `8                                     .o8    `"'
#  888         oooo  oooo  ooo. .oo.    .ooooo.  .o888oo oooo   .ooooo.  ooo. .oo.    .oooo.o
#  888oooo8    `888  `888  `888P"Y88b  d88' `"Y8   888   `888  d88' `88b `888P"Y88b  d88(  "8
#  888    "     888   888   888   888  888         888    888  888   888  888   888  `"Y88b.
#  888          888   888   888   888  888   .o8   888 .  888  888   888  888   888  o.  )88b
# o888o         `V88V"V8P' o888o o888o `Y8bod8P'   "888" o888o `Y8bod8P' o888o o888o 8""888P'


def get_props():
    """get useful props used in interface""" 
    #IMPORTANT NOTE: perhaps a bad idea to constanly call this funciton in GUI, too many repetitive calls?

    scat_win = bpy.context.window_manager.scatter5
    scat_ui = scat_win.ui
    scat_scene = bpy.context.scene.scatter5
    emitter = scat_scene.emitter
    psy_active = emitter.scatter5.get_psy_active()
    group_active  = emitter.scatter5.get_group_active()

    return (scat_scene, scat_ui, scat_win, emitter, psy_active, group_active)

def warnings(layout, active=True, created=True,):
    """check if interface should be drawn, if nothing created or active"""

    emitter    = bpy.context.scene.scatter5.emitter
    psy_active = emitter.scatter5.get_psy_active()

    if (psy_active is None):
        txt = layout.row()
        txt.alignment = "CENTER"
        txt.label(text=translate("No System(s) Active."), icon="INFO",) #unlikely
        ui_templates.separator_box_in(layout)
        return True
    return False

def lock_check(psy_active, s_category="s_distribution", prop=None,):
    """check if category is locked"""

    if psy_active.is_locked(s_category):
        return False 
    return prop

def active_check(psy_active, s_category="s_distribution", prop=None,):
    """check if category master allow is off"""

    if (not getattr(psy_active,f"{s_category}_master_allow")):
        return False 
    return prop


#  8888b.  88""Yb    db    Yb        dP     888888 888888 8b    d8 88""Yb 88        db    888888 888888 .dP"Y8
#   8I  Yb 88__dP   dPYb    Yb  db  dP        88   88__   88b  d88 88__dP 88       dPYb     88   88__   `Ybo."
#   8I  dY 88"Yb   dP__Yb    YbdPYbdP         88   88""   88YbdP88 88"""  88  .o  dP__Yb    88   88""   o.`Y8b
#  8888Y"  88  Yb dP""""Yb    YP  YP          88   888888 88 YY 88 88     88ood8 dP""""Yb   88   888888 8bodP'


def draw_visibility_methods(psy_active, layout, api):
    """draw viewport method in visibility and display features"""

    if (not layout):
        return None
    
    from ... __init__ import addon_prefs
    
    if (addon_prefs().debug_interface):
        row = layout.row(align=True)
        row.alignment = "RIGHT"
        row.scale_x = 0.9
        row.prop(psy_active,f"{api}_viewport_method", text="",)

    row = layout.box().row(align=True)
    row.alignment = "RIGHT"
    row.scale_y = 0.4
    row.scale_x = 0.95
    
    is_shaded = getattr(psy_active, f"{api}_allow_shaded")
    is_render = getattr(psy_active, f"{api}_allow_render")

    row.emboss = "NONE"
    rwoo = row.row(align=True) ; rwoo.active = True      ; rwoo.prop(psy_active,f"{api}_allow_screen", text="", icon="RESTRICT_VIEW_OFF",)
    rwoo = row.row(align=True) ; rwoo.active = is_shaded ; rwoo.prop(psy_active,f"{api}_allow_shaded", text="", icon="SHADING_RENDERED" if is_shaded else "NODE_MATERIAL",)
    rwoo = row.row(align=True) ; rwoo.active = True      ; rwoo.prop(psy_active,f"{api}_allow_render", text="", icon="RESTRICT_RENDER_OFF" if is_render else "RESTRICT_RENDER_ON",)

    return None 

def draw_coll_str_ptr(layout=None, system=None, api="", revert_api="", add_coll_name="", add_parent_name="Geo-Scatter User Col", draw_popover=True,):
    """draw collection pointer template, for psy or group"""
        
    str_value = getattr(system,api)
    coll_found = bpy.data.collections.get(str_value)

    row = layout.row(align=True)

    #draw popover?
    if (coll_found and draw_popover):
        pop = row.row(align=True)
        #transfer arguments for collection drawing & add/remove buttons
        pop.context_string_set("pass_ui_arg_collapi", api,)
        pop.context_pointer_set("pass_ui_arg_collptr", coll_found,)
        pop.popover(panel="SCATTER5_PT_collection_popover", text="", icon="OUTLINER",)

    #draw str prop search
    ptr = row.row(align=True)
    ptr.alert = ( bool(str_value) and (not coll_found) )
    ptr.prop(system, api, text="", icon="OUTLINER_COLLECTION", placeholder=" "+translate("Collection"),)

    #draw reverse arrow?
    if (coll_found and revert_api):
        row.prop(system, revert_api, text="", icon="ARROW_LEFTRIGHT",)
    
    #draw create button if ptr is None
    if (str_value==""):
        op = row.operator("scatter5.create_coll", text="", icon="ADD",)
        op.api = f"{'psy_active' if (system.system_type=='SCATTER_SYSTEM') else 'group_active'}.{api}" 
        op.pointer_type = "str"
        op.coll_name = add_coll_name
        op.parent_name = add_parent_name

    return coll_found, row

def draw_camera_update_method(layout=None, psy_active=None):
    """draw context_scene.scatter5 camera update dependencies method"""

    from ... __init__ import blend_prefs
    scat_data  = blend_prefs()

    col = layout.column(align=True)
    txt = col.row()
    txt.label(text=translate("Cam Update")+" :")

    col.prop(scat_data, "factory_cam_update_method", text="",)

    if (scat_data.factory_cam_update_method=="update_delayed"):
        col.prop(scat_data, "factory_cam_update_secs")
        col.separator(factor=0.5)

    elif (scat_data.factory_cam_update_method=="update_apply") and psy_active:
        col.operator("scatter5.exec_line", text=translate("Refresh"), icon="FILE_REFRESH",).api = "update_camera_nodegroup(scene=C.scene, force_update=True, reset_hash=True,)"
        col.separator(factor=0.5)

    return None 

def draw_transition_control_feature(layout=None, psy_active=None, api="", fallnoisy=True,):
    """draw the transition control feature, this feature is repeated many times"""

    tocol, is_toggled = ui_templates.bool_toggle(layout, psy_active, f"{api}_fallremap_allow",
        label=translate("Transition Control"),
        icon="FCURVE", 
        use_layout_left_spacer=False,
        return_sublayout=True,
        )
    if is_toggled:

        #special case for camera distance, nodes is not the same as api
        if (api=="s_visibility_camdist"):
            api = "s_visibility_cam"

        #find back the fallremap node, the name node names & structure are standardized, otherwise will lead to issues!
        opapi = f"bpy.data.objects['{psy_active.scatter_obj.name}'].modifiers['{psy_active.get_scatter_mod().name}'].node_group.nodes['{api}'].node_tree.nodes['fallremap']"
        
        ope = tocol.row(align=True)
        op = ope.operator("scatter5.graph_dialog", text=translate("Falloff Graph"), icon="FCURVE",)
        op.source_api = opapi
        op.mapping_api = f"{opapi}.mapping"
        op.psy_name = psy_active.name
            
        #special case for camera distance
        if (api=="s_visibility_cam"):
              ope.prop(psy_active, f"s_visibility_camdist_fallremap_revert", text="", icon="ARROW_LEFTRIGHT",)
        else: ope.prop(psy_active, f"{api}_fallremap_revert", text="", icon="ARROW_LEFTRIGHT",)

        tocol.separator(factor=0.3)

        if (fallnoisy):

            noisyt = tocol.column(align=True)
            noisyt.scale_y = 0.9
            noisyt.label(text=translate("Noise")+":")
            noisyt.prop(psy_active, f"{api}_fallnoisy_strength")
            noisytt = noisyt.column(align=True)
            noisytt.active = getattr(psy_active, f"{api}_fallnoisy_strength")!=0
            noisytt.prop(psy_active, f"{api}_fallnoisy_scale")
            noisyp = noisytt.row(align=True)
            noisyp.prop(psy_active, f"{api}_fallnoisy_seed")
            noisyb = noisyp.row(align=True)
            noisyb.scale_x = 1.2
            noisyb.prop(psy_active, f"{api}_fallnoisy_is_random_seed", icon_value=cust_icon("W_DICE"), text="",)

            tocol.separator(factor=0.3)

    return tocol, is_toggled 

def draw_universal_masks(layout=None, mask_api="", psy_api=None,):
    """every universal masks api should have _mask_ptr _mask_reverse"""

    #group_api = "particle_groups" if (system.system_type=='SCATTER_SYSTEM') else "particle_groups" if (system.system_type=='SCATTER_GROUP') else "ERROR_NOT_FOUND"
    
    col = layout.column(align=True)

    col.separator(factor=0.5)

    # title = col.row(align=True)
    # title.scale_y = 0.9
    # title.label(text=translate("Feature Mask")+":",)

    tocol, is_toggled = ui_templates.bool_toggle(col, psy_api, f"{mask_api}_mask_allow",
        label=translate("Feature Mask"),
        icon="MOD_OPACITY",
        use_layout_left_spacer=False,
        return_sublayout=True,
        )
    if is_toggled:

        _mask_ptr_str = f"{mask_api}_mask_ptr"
        _mask_ptr_val = getattr(psy_api, f"{mask_api}_mask_ptr")
        _mask_method_val = getattr(psy_api, f"{mask_api}_mask_method")
        _mask_color_sample_method_val = getattr(psy_api, f"{mask_api}_mask_color_sample_method")

        methodcol = tocol.column(align=True)
        # methodcol.label(text=translate("Mask Type")+":",)
        method = methodcol.row(align=True)
        method.prop(psy_api, f"{mask_api}_mask_method", text="",)# icon_only=True, emboss=True,)

        match _mask_method_val:

            case "mask_vg": ################################ Vgroup Method
                    
                tocol.separator(factor=0.4)

                #Mask Ptr

                mask = tocol.row(align=True)

                ptr = mask.row(align=True)
                ptr_filled = bool(_mask_ptr_val)
                ptr_acrossall = is_attr_surfs_shared(system=psy_api, attr_type='vg', attr_name=_mask_ptr_val,)
                ptr.alert = (ptr_filled and not ptr_acrossall) or (ptr_filled and not psy_api.is_using_surf)
                ptr.prop(psy_api, _mask_ptr_str, text="", icon="GROUP_VERTEX", placeholder=" "+translate("Vertex-Group"),)

                buttons = mask.row(align=True)
                buttons.scale_x = 0.93

                if (_mask_ptr_val!=""):
                    buttons.prop(psy_api, f"{mask_api}_mask_reverse", text="", icon="ARROW_LEFTRIGHT",)

                op = buttons.operator("scatter5.vg_quick_paint",
                    text="",
                    icon="BRUSH_DATA" if _mask_ptr_val else "ADD",
                    depress=((bpy.context.mode=="PAINT_WEIGHT") and (getattr(bpy.context.object.vertex_groups.active,"name",'')==_mask_ptr_val)),
                    )
                op.group_name = _mask_ptr_val
                op.mode = "vg"
                op.api = f"emitter.scatter5.particle_systems['{psy_api.name}'].{_mask_ptr_str}"

            case "mask_vcol": ################################ Color Attribute Method
                
                tocol.separator(factor=0.4)

                #set color
                set_color = (1,1,1)
                if (_mask_ptr_val!=""):
                    equivalence = {"id_picker":getattr(psy_api,f"{mask_api}_mask_id_color_ptr"),"id_greyscale":(1,1,1),"id_red":(1,0,0),"id_green":(0,1,0),"id_blue":(0,0,1),"id_black":(0,0,0),"id_white":(1,1,1),"id_saturation":(1,1,1),"id_value":(1,1,1),"id_hue":(1,1,1),"id_lightness":(1,1,1),"id_alpha":(1,1,1),}
                    set_color = equivalence[_mask_color_sample_method_val]

                #Mask Ptr

                mask = tocol.row(align=True)

                ptr = mask.row(align=True)
                ptr_filled = bool(_mask_ptr_val)
                ptr_acrossall = is_attr_surfs_shared(system=psy_api, attr_type='vcol', attr_name=_mask_ptr_val,)
                ptr.alert = (ptr_filled and not ptr_acrossall) or (ptr_filled and not psy_api.is_using_surf)
                ptr.prop(psy_api, _mask_ptr_str, text="", icon="GROUP_VCOL", placeholder=" "+translate("Color Attribute"),)

                buttons = mask.row(align=True)
                buttons.scale_x = 0.93

                if (_mask_ptr_val!=""):
                    buttons.prop(psy_api, f"{mask_api}_mask_reverse", text="", icon="ARROW_LEFTRIGHT",)

                op = buttons.operator("scatter5.vg_quick_paint",
                    text="", icon="BRUSH_DATA" if _mask_ptr_val else "ADD",
                    depress=((bpy.context.mode=="PAINT_VERTEX") and (getattr(bpy.context.object.data.color_attributes.active_color,"name",'')==_mask_ptr_val)),
                    )
                op.group_name =_mask_ptr_val
                op.mode = "vcol"
                op.set_color = set_color
                op.api = f"emitter.scatter5.particle_systems['{psy_api.name}'].{_mask_ptr_str}"

                #sample method

                if (_mask_ptr_val!=""):

                    tocol.label(text=translate("Sample")+":")
                    sampl = tocol.column(align=True)
                    sampl.scale_y = 0.95
                    meth = sampl.row(align=True)
                    meth.prop(psy_api, f"{mask_api}_mask_color_sample_method", text="",)
                    if (_mask_color_sample_method_val=="id_picker"):
                        color = meth.row(align=True)
                        color.scale_x = 0.35
                        color.prop(psy_api, f"{mask_api}_mask_id_color_ptr", text="",)
                                
            case "mask_bitmap": ################################ Image Method

                tocol.separator(factor=0.4)

                _mask_bitmap_ptr_val = getattr(psy_api, f"{mask_api}_mask_bitmap_ptr")
                _mask_bitmap_uv_ptr_val = getattr(psy_api, f"{mask_api}_mask_bitmap_uv_ptr")

                #set color
                set_color = (0,0,0)
                if (_mask_bitmap_ptr_val!=""):
                    equivalence = {"id_picker":getattr(psy_api,f"{mask_api}_mask_id_color_ptr"),"id_greyscale":(1,1,1),"id_red":(1,0,0),"id_green":(0,1,0),"id_blue":(0,0,1),"id_black":(0,0,0),"id_white":(1,1,1),"id_saturation":(1,1,1),"id_value":(1,1,1),"id_hue":(1,1,1),"id_lightness":(1,1,1),"id_alpha":(1,1,1),}
                    set_color = equivalence[_mask_color_sample_method_val]
                    
                #Mask Ptr

                mask = tocol.row(align=True)
                
                ptr = mask.row(align=True)
                ptr.alert = ( bool(_mask_bitmap_ptr_val) and (_mask_bitmap_ptr_val not in bpy.data.images) )
                ptr.prop(psy_api, f"{mask_api}_mask_bitmap_ptr", text="", icon="IMAGE_DATA", placeholder=" "+translate("Image"),)

                buttons = mask.row(align=True)
                buttons.scale_x = 0.93

                if (_mask_bitmap_ptr_val!=""):
                    buttons.prop(psy_api, f"{mask_api}_mask_reverse", text="", icon="ARROW_LEFTRIGHT",)

                op = buttons.operator("scatter5.image_utils",
                    text="", icon="BRUSH_DATA" if _mask_bitmap_ptr_val else "ADD",
                    depress=((bpy.context.mode=="PAINT_TEXTURE") and (bpy.context.scene.tool_settings.image_paint.mode=='IMAGE') and (bpy.context.scene.tool_settings.image_paint.canvas==bpy.data.images.get(_mask_bitmap_ptr_val)) and (bpy.context.object.data.uv_layers.active) and (bpy.context.object.data.uv_layers.active.name==_mask_bitmap_uv_ptr_val)),
                    )
                if (_mask_bitmap_ptr_val==""):
                    op.option = "new"
                    op.img_name = _mask_bitmap_ptr_val
                    op.api = f"emitter.scatter5.particle_systems['{psy_api.name}'].{mask_api}_mask_bitmap_ptr"
                else:
                    op.option = "paint"
                    op.paint_color = set_color
                    op.uv_ptr = _mask_bitmap_uv_ptr_val
                    op.img_name = _mask_bitmap_ptr_val
                    op.api = f"emitter.scatter5.particle_systems['{psy_api.name}'].{mask_api}_mask_bitmap_ptr"

                if (_mask_bitmap_ptr_val!=""):
                    tocol.separator(factor=0.1)
                    ptr = tocol.row(align=True)
                    ptr.alert = ( bool(_mask_bitmap_uv_ptr_val) and not is_attr_surfs_shared(system=psy_api, attr_type='uv', attr_name=_mask_bitmap_uv_ptr_val,) )
                    ptr.prop(psy_api, f"{mask_api}_mask_bitmap_uv_ptr", text="", icon="GROUP_UVS", placeholder=" "+translate("UV Map"),)

                #sample method

                if (_mask_bitmap_ptr_val!=""):

                    tocol.label(text=translate("Sample")+":")
                    sampl = tocol.column(align=True)
                    sampl.scale_y = 0.95
                    meth = sampl.row(align=True)
                    meth.prop(psy_api, f"{mask_api}_mask_color_sample_method", text="",)
                    if (_mask_color_sample_method_val=="id_picker"):
                        color = meth.row(align=True)
                        color.scale_x = 0.35
                        color.prop(psy_api, f"{mask_api}_mask_id_color_ptr", text="",)  

            case "mask_noise": ################################ Noise Method

                tocol.label(text=translate("Space")+":")
                tocol.prop(psy_api, f"{mask_api}_mask_noise_space", text="",)
                
                tocol.separator(factor=0.1)

                noise_sett = tocol.column(align=True)
                noise_sett.scale_y = 0.9
                noise_sett.label(text=translate("Settings")+":")

                noise_sett.prop(psy_api, f"{mask_api}_mask_noise_scale",)
                noise_sett.prop(psy_api, f"{mask_api}_mask_noise_brightness",)
                noise_sett.prop(psy_api, f"{mask_api}_mask_noise_contrast",)

                sed = noise_sett.row(align=True)
                sed.prop(psy_api, f"{mask_api}_mask_noise_seed")
                sedbutton = sed.row(align=True)
                sedbutton.scale_x = 1.2
                sedbutton.prop(psy_api,f"{mask_api}_mask_noise_is_random_seed", icon_value=cust_icon("W_DICE"), text="",)
            

    return None

def draw_feature_influence(layout=None, system=None, api_name="",):
    """draw the feature influence api"""

    col=layout.column(align=True)
    lbl=col.row()
    lbl.scale_y = 0.9
    lbl.label(text=translate("Influence")+":")

    #loop the 4 possible domain influence, density, scale or rotation 2x

    for dom in ("dist","scale","nor","tan"): 

        domain_api = f"{api_name}_{dom}"
        prop = f"{domain_api}_infl_allow"

        #is property domain supported? 
        if (prop not in system.bl_rna.properties.keys()): 
            continue

        allow = getattr(system,prop)
            
        #enable influence
        row = col.row(align=True)
        enabled = getattr(system, prop)
        
        row.prop(system, prop, text="", icon="CHECKBOX_HLT" if enabled else "CHECKBOX_DEHLT",)

        row = row.row(align=True)
        row.enabled = enabled

        #influence value 
        row.prop(system, f"{domain_api}_influence")

        #influence revert if exists?
        rev_api = f"{domain_api}_revert"
        if (rev_api in system.bl_rna.properties.keys()): 
            row.prop(system, rev_api, text="", icon="ARROW_LEFTRIGHT",)

        continue

    return None 


# ooo        ooooo            o8o                   ooooooooo.                                   oooo
# `88.       .888'            `"'                   `888   `Y88.                                 `888
#  888b     d'888   .oooo.   oooo  ooo. .oo.         888   .d88'  .oooo.   ooo. .oo.    .ooooo.   888
#  8 Y88. .P  888  `P  )88b  `888  `888P"Y88b        888ooo88P'  `P  )88b  `888P"Y88b  d88' `88b  888
#  8  `888'   888   .oP"888   888   888   888        888          .oP"888   888   888  888ooo888  888
#  8    Y     888  d8(  888   888   888   888        888         d8(  888   888   888  888    .o  888
# o8o        o888o `Y888""8o o888o o888o o888o      o888o        `Y888""8o o888o o888o `Y8bod8P' o888o


def draw_tweaking_panel(self, layout, context,):
    """draw main tweaking panel"""

    scat_scene, scat_ui, scat_win, emitter, psy_active, group_active = get_props()

    main = layout.column()

    ui_templates.separator_box_out(main)
    ui_templates.separator_box_out(main)

    draw_particle_selection(self, main, context,)
    ui_templates.separator_box_out(main)

    if (group_active is not None):
        
        draw_group_beginner_masks(self, main)
        ui_templates.separator_box_out(main)
    
    
    elif (psy_active is not None):
        
        draw_beginner_interface(self, main)
        ui_templates.separator_box_out(main)

        draw_removal_interface(self, main)
        ui_templates.separator_box_out(main)


    draw_pros_interface(self, main, context)
    ui_templates.separator_box_out(main)

    ui_templates.separator_box_out(main)
    ui_templates.separator_box_out(main)

    return 


#  .oooooo..o           oooo                          .    o8o                                   .o.
# d8P'    `Y8           `888                        .o8    `"'                                  .888.
# Y88bo.       .ooooo.   888   .ooooo.   .ooooo.  .o888oo oooo   .ooooo.  ooo. .oo.            .8"888.     oooo d8b  .ooooo.   .oooo.
#  `"Y8888o.  d88' `88b  888  d88' `88b d88' `"Y8   888   `888  d88' `88b `888P"Y88b          .8' `888.    `888""8P d88' `88b `P  )88b
#      `"Y88b 888ooo888  888  888ooo888 888         888    888  888   888  888   888         .88ooo8888.    888     888ooo888  .oP"888
# oo     .d8P 888    .o  888  888    .o 888   .o8   888 .  888  888   888  888   888        .8'     `888.   888     888    .o d8(  888
# 8""88888P'  `Y8bod8P' o888o `Y8bod8P' `Y8bod8P'   "888" o888o `Y8bod8P' o888o o888o      o88o     o8888o d888b    `Y8bod8P' `Y888""8o


def draw_particle_selection(self, layout, context,):

    scat_scene, scat_ui, scat_win, emitter, psy_active, group_active = get_props()

    extra_layout, box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_tweak_select", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_tweak_select");BOOL_VALUE(1)
        panel_icon="PARTICLES", 
        panel_name=translate("System(s) List"),
        popover_info="SCATTER5_PT_docs", 
        popover_uilayout_context_set="ui_tweak_select",
        return_subpanel=True,
        )
    if is_open:

        from .ui_system_list import draw_particle_selection_inner
        draw_particle_selection_inner(layout=box, context=context, extra_layout=extra_layout, scat_scene=scat_scene, emitter=emitter, psy_active=psy_active, group_active=group_active,)

        ui_templates.separator_box_in(box)

    return None



# ooooo                          .
# `888'                        .o8
#  888  ooo. .oo.    .oooo.o .o888oo  .oooo.   ooo. .oo.    .ooooo.   .ooooo.   .oooo.o
#  888  `888P"Y88b  d88(  "8   888   `P  )88b  `888P"Y88b  d88' `"Y8 d88' `88b d88(  "8
#  888   888   888  `"Y88b.    888    .oP"888   888   888  888       888ooo888 `"Y88b.
#  888   888   888  o.  )88b   888 . d8(  888   888   888  888   .o8 888    .o o.  )88b
# o888o o888o o888o 8""888P'   "888" `Y888""8o o888o o888o `Y8bod8P' `Y8bod8P' 8""888P'


class SCATTER5_UL_list_instances(bpy.types.UIList):
    """instance area"""

    def __init__(self, *args, **kwargs):
        """set default drawing UIList options"""
        
        super().__init__(*args, **kwargs)
        
        self.use_filter_sort_alpha = True
        self.use_filter_show = False
        
        return None
        
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        
        if not item:
            return 

        scat_scene, scat_ui, scat_win, emitter, psy_active, group_active = get_props()
        coll = psy_active.s_instances_coll_ptr

        #find index 

        i = None
        for i,o in enumerate(sorted(coll.objects, key= lambda o:o.name)):
            i+=1
            if o==item:
                break

        row = layout.row(align=True)
        row.scale_y = 0.7

        #select operator 

        selct = row.row()

        if (bpy.context.mode=="OBJECT"):

            selct.active = (item==bpy.context.object)
            op = selct.operator("scatter5.select_object",emboss=False, text="", icon="RESTRICT_SELECT_OFF" if item in bpy.context.selected_objects else "RESTRICT_SELECT_ON")
            op.obj_session_uid = item.session_uid
            op.coll_name = coll.name

        #name? or linked label?
        
        if bool(item.library):
            lnk = row.row()
            lnk.label(text=item.name, icon="LINKED",)
        else:
            name = row.row()
            name.prop(item,"name", text="", emboss=False, )

        #pick method chosen? 

        if (psy_active.s_instances_pick_method != "pick_random"):

            #pick rate slider 

            if (psy_active.s_instances_pick_method == "pick_rate"):

                slider = row.row()

                if (i<=20):
                    slider.prop(psy_active, f"s_instances_id_{i:02}_rate", text="",)
                else:
                    slider.alignment = "RIGHT"
                    slider.label(text=translate("Not Supported"),)

            #pick index 

            elif (psy_active.s_instances_pick_method == "pick_idx"):

                slider = row.row()
                slider.alignment= "RIGHT"
                slider.label(text=f"{i-1:02} ")

            #pick scale 

            elif (psy_active.s_instances_pick_method == "pick_scale"):

                slider = row.row(align=True)

                if (i<=20):
                    slider.scale_x = 0.71
                    slider.prop(psy_active, f"s_instances_id_{i:02}_scale_min", text="",)
                    slider.prop(psy_active, f"s_instances_id_{i:02}_scale_max", text="",)
                else:
                    slider.operator("scatter5.dummy",text=translate("Not Supported"),)

            #pick color 

            elif (psy_active.s_instances_pick_method == "pick_color"):

                clr = row.row(align=True)
                clr.alignment = "RIGHT"

                if (i<=20):
                      clr.prop(psy_active, f"s_instances_id_{i:02}_color", text="",)
                else: clr.label(text=translate("Not Supported"),)

        #remove operator 

        ope = row.row(align=False)
        ope.scale_x = 0.9
        ope.operator("scatter5.remove_instances",emboss=False, text="", icon="TRASH",).obj_session_uid = item.session_uid

        return



# oooooooooo.                        o8o
# `888'   `Y8b                       `"'
#  888     888  .ooooo.   .oooooooo oooo  ooo. .oo.   ooo. .oo.    .ooooo.  oooo d8b  .oooo.o
#  888oooo888' d88' `88b 888' `88b  `888  `888P"Y88b  `888P"Y88b  d88' `88b `888""8P d88(  "8
#  888    `88b 888ooo888 888   888   888   888   888   888   888  888ooo888  888     `"Y88b.
#  888    .88P 888    .o `88bod8P'   888   888   888   888   888  888    .o  888     o.  )88b
# o888bood8P'  `Y8bod8P' `8oooooo.  o888o o888o o888o o888o o888o `Y8bod8P' d888b    8""888P'
#                        d"     YD
#                        "Y88888P'


sepa_small = 0.15
sepa_large = 3.15

def draw_beginner_interface(self,layout):

    scat_scene, scat_ui, scat_win, emitter, psy_active, group_active = get_props()

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_tweak_beginners", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_tweak_beginners");BOOL_VALUE(1)
        panel_name=translate("Beginner Interface"),
        )
    if is_open:

            if warnings(box):
                return None

            main = box.column()

            row = main.row()
            s1 = row.column()
            s1.scale_x = 1.25
            s1.active = True
            s1.alignment = "RIGHT"
            s2 = row.column() 

            #density controls 

            if (psy_active.s_distribution_method=="random"):
                s1.label(text=translate("Density"),)
                s2.prop(psy_active, "s_distribution_density", text="",)

                s1.label(text="Collision")
                ope = s2.row(align=True)
                ope.prop(psy_active,"s_distribution_limit_distance_allow", text="", icon="CHECKBOX_HLT" if psy_active.s_distribution_limit_distance_allow else "CHECKBOX_DEHLT")
                ope2 = ope.row(align=True)
                ope2.enabled = psy_active.s_distribution_limit_distance_allow
                ope2.prop(psy_active,"s_distribution_limit_distance", text="",) 
                
            else:
                s1.label(text=translate("Density"),)
                ope = s2.row()
                ope.active = False
                ope.operator("scatter5.dummy", text=translate("Read Only"),)

            s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

            #vgroup paint

            s1.label(text=translate("Vertex-Group"),)

            ope = s2.row(align=True)
            ope.prop(psy_active,"s_mask_vg_allow", text="", icon="CHECKBOX_HLT" if psy_active.s_mask_vg_allow else "CHECKBOX_DEHLT")
            ope2 = ope.row(align=True)
            ope2.enabled = psy_active.s_mask_vg_allow
            exists = (psy_active.s_mask_vg_ptr!="")
            op = ope2.operator("scatter5.vg_quick_paint",
                text="Paint",
                icon="BRUSH_DATA" if (exists) else "ADD",
                depress=((bpy.context.mode=="PAINT_WEIGHT") and (getattr(bpy.context.object.vertex_groups.active,"name",'')==psy_active.s_mask_vg_ptr)),
                )
            op.group_name = psy_active.s_mask_vg_ptr
            op.mode = "vg" 
            op.api = f"emitter.scatter5.particle_systems['{psy_active.name}'].s_mask_vg_ptr"

            s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

            #seed 

            s1.label(text=translate("Seed"),)
            ope = s2.row(align=True)
            op = ope.operator("scatter5.exec_line", text=translate("Randomize"), icon_value=cust_icon("W_DICE"),)
            op.api = f"psy_active.s_distribution_is_random_seed = True ; psy_active.get_scatter_mod().node_group.nodes['s_pattern1'].node_tree.nodes['texture'].node_tree.scatter5.texture.mapping_random_is_random_seed = True"
            op.description = translate("Randomize the seed of this distribution")
            
            #scale

            s1.separator(factor=sepa_large) ; s2.separator(factor=sepa_large)

            s1.label(text=translate("Scale"),)
            s2.prop(psy_active,"s_beginner_default_scale", text="",) 

            s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

            s1.label(text=translate("Random"),)
            s2.prop(psy_active,"s_beginner_random_scale", text="", slider=True,) 

            s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

            s1.label(text=translate("Vertex-Group"),)

            ope = s2.row(align=True)

            op = ope.operator("scatter5.exec_line", text="", icon="CHECKBOX_HLT" if psy_active.s_scale_shrink_allow else "CHECKBOX_DEHLT", depress=psy_active.s_scale_shrink_allow, )
            op.api = f"psy_active.s_scale_shrink_allow = {not psy_active.s_scale_shrink_allow} ; psy_active.s_scale_shrink_mask_method = 'mask_vg' ; psy_active.s_scale_shrink_mask_reverse = True"
            op.description = translate("Paint a scale shrink mask with the help of a vertex-group")
            
            ope2 = ope.row(align=True)
            ope2.enabled = psy_active.s_scale_shrink_allow
            exists = (psy_active.s_scale_shrink_mask_ptr!="")
            op = ope2.operator("scatter5.vg_quick_paint",
                text="Paint",
                icon="BRUSH_DATA" if exists else "ADD",
                depress=((bpy.context.mode=="PAINT_WEIGHT") and (getattr(bpy.context.object.vertex_groups.active,"name",'')==psy_active.s_scale_shrink_mask_ptr)),
                )
            op.group_name = psy_active.s_scale_shrink_mask_ptr
            op.mode = "vg" 
            op.api = f"emitter.scatter5.particle_systems['{psy_active.name}'].s_scale_shrink_mask_ptr"

            #rotation 

            s1.separator(factor=sepa_large) ; s2.separator(factor=sepa_large)

            s1.label(text=translate("Rotation Align"),)
            ope = s2.row(align=True)
            op = ope.operator("scatter5.exec_line",text=translate("Normal"), depress=(psy_active.s_rot_align_z_allow and psy_active.s_rot_align_z_method=='meth_align_z_normal'),)
            op.api = f"psy_active.s_rot_align_z_allow = True ;  psy_active.s_rot_align_z_method ='meth_align_z_normal'"
            op.description = translate("Align the +Z direction of your instances to your surface normal")

            op = ope.operator("scatter5.exec_line",text=translate("Local Z"), depress=(psy_active.s_rot_align_z_allow and psy_active.s_rot_align_z_method=='meth_align_z_local'),)
            op.api = f"psy_active.s_rot_align_z_allow = True ;  psy_active.s_rot_align_z_method ='meth_align_z_local'"
            op.description = translate("Align the +Z direction of your instances to the +Z direction of your surface object")
            
            s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

            s1.label(text=translate("Random"),)
            s2.prop(psy_active,"s_beginner_random_rot", text="", slider=True,)

            #texture

            s1.separator(factor=sepa_large) ; s2.separator(factor=sepa_large)

            #find node
            patnode = psy_active.get_scatter_node("s_pattern1", strict=True, raise_exception=False,)
            if (patnode is None):
                s1.label(text="Error, Node missing")
                return
            texture_node = patnode.node_tree.nodes["texture"]
            texture_exists = True
            texture_props = texture_node.node_tree.scatter5.texture

            if (texture_node.node_tree.name.startswith(".TEXTURE *DEFAULT")):

                s1.label(text=translate("Pattern"),)
                ope = s2.row(align=True)
                ope.context_pointer_set("pass_ui_arg_system", psy_active,)
                ope.context_pointer_set("pass_ui_arg_texture_node", texture_node,)
                op = ope.operator("scatter5.exec_line", text=translate("New"), icon="ADD",)
                op.api = "bpy.ops.scatter5.scatter_texture_new(ptr_name='s_pattern1_texture_ptr',new_name='BR-Pattern') ; psy_active.s_pattern1_allow = True"
                op.description = translate("Create a new Pattern texture, a procedural noise used to mask your distribution density and influence your instances scale")
                op.undo = "Creating New Pattern"

            elif (psy_active.s_pattern1_allow):

                s1.label(text=translate("Pattern"),)
                ope = s2.row(align=True)
                op = ope.operator("scatter5.exec_line", text=translate("Active"), icon="CHECKBOX_HLT", depress=True)
                op.api = f"psy_active.s_pattern1_allow = False"
                op.description = translate("Disable the procedural noise pattern influencing your distribution")

                s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

                s1.label(text=translate("Scale"),)
                s2.prop(texture_props, "scale", text="",)

                s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

                s1.label(text=translate("Brightness"),)
                s2.prop(texture_props, "intensity", text="",)

                s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

                s1.label(text=translate("Contrast"),)
                s2.prop(texture_props, "contrast", text="",)

                s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

                
            else:

                s1.label(text=translate("Pattern"),)
                ope = s2.row(align=True)
                op = ope.operator("scatter5.exec_line", text=translate("Inactive"), icon="CHECKBOX_DEHLT", depress=False,)
                op.api = f"psy_active.s_pattern1_allow = True"
                op.description = translate("Enable the procedural noise pattern influencing your distribution")

            #define instances 

            s1.separator(factor=sepa_large) ; s2.separator(factor=sepa_large)

            s1.label(text=translate("Displays"),)

            ope = s2.row(align=True)
            op = ope.operator("scatter5.exec_line", text=translate("Active") if psy_active.s_display_allow else translate("Inactive"), icon="CHECKBOX_HLT" if psy_active.s_display_allow else "CHECKBOX_DEHLT", depress=psy_active.s_display_allow, )
            op.api = f"psy_active.s_display_allow = {not psy_active.s_display_allow}"
            op.description = translate("Display your instances as lowpoly objects to draw less triangles on your screen and saving on GPU performance when navigating the viewport")

            s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

            s1.label(text=translate("Instances"),)

            ui_list = s2.column(align=True)
            ui_list.template_list("SCATTER5_UL_list_instances", "", psy_active.s_instances_coll_ptr, "objects", psy_active, "ui_instances_list_idx", rows=5, sort_lock=True,)
                
            add = ui_list.column(align=True)
            add.active = (bpy.context.mode=="OBJECT")
            add.operator_menu_enum("scatter5.add_instances", "method", text=translate("Add Instance(s)"), icon="ADD",)
        
            #Separator 

            ui_templates.separator_box_in(box)

    return

def draw_removal_interface(self,layout):

    scat_scene, scat_ui, scat_win, emitter, psy_active, group_active = get_props()

    if (psy_active is None):
        return

    s_abiotic_used    = psy_active.is_category_used("s_abiotic")
    s_ecosystem_used  = psy_active.is_category_used("s_ecosystem")
    s_proximity_used  = psy_active.is_category_used("s_proximity")
    s_push_used       = psy_active.is_category_used("s_push")
    s_wind_used       = psy_active.is_category_used("s_wind")
    s_visibility_used = psy_active.is_category_used("s_visibility")

    if any([s_abiotic_used, s_ecosystem_used, s_proximity_used, s_push_used, s_wind_used, s_visibility_used,]):

        box, is_open = ui_templates.box_panel(layout, 
            panelopen_propname="ui_tweak_removal", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_tweak_removal");BOOL_VALUE(1)
            panel_name=translate("Advanced Features"),
            popover_info="SCATTER5_PT_docs", 
            popover_uilayout_context_set="s_beginners_remove",
            )
        if is_open:

            main = box.column()

            row = main.row()
            split = row.split(factor = 0.375)
            s1 = split.column()
            s1.alignment = "RIGHT"
            s2 = split.column()

            s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

            if (s_visibility_used):
                s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

                s1.label(text=translate("Optimizations"),)
                ope = s2.row(align=True)
                op = ope.operator("scatter5.exec_line", text=translate("Remove"), icon="PANEL_CLOSE", depress=False,)
                op.api = f"psy_active.s_visibility_master_allow = False"
                op.undo = translate("Remove Visibility Features")
                op.description = translate("There are more advanced features enabled for this scatter-system, however these are not available for Biome-Reader! Would you like to remove them?")

            if (s_abiotic_used):
                s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

                s1.label(text=translate("Abiotic"),)
                ope = s2.row(align=True)
                op = ope.operator("scatter5.exec_line", text=translate("Remove"), icon="PANEL_CLOSE", depress=False,)
                op.api = f"psy_active.s_abiotic_master_allow = False"
                op.undo = translate("Remove Abiotic Features")
                op.description = translate("There are more advanced features enabled for this scatter-system, however these are not available for Biome-Reader! Would you like to remove them?")

            if (s_ecosystem_used):
                s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

                s1.label(text=translate("Ecosystem"),)
                ope = s2.row(align=True)
                op = ope.operator("scatter5.exec_line", text=translate("Remove"), icon="PANEL_CLOSE", depress=False,)
                op.api = f"psy_active.s_ecosystem_master_allow = False"
                op.undo = translate("Remove Ecosystem Features")
                op.description = translate("There are more advanced features enabled for this scatter-system, however these are not available for Biome-Reader! Would you like to remove them?")

            if (s_proximity_used):
                s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

                s1.label(text=translate("Proximity"),)
                ope = s2.row(align=True)
                op = ope.operator("scatter5.exec_line", text=translate("Remove"), icon="PANEL_CLOSE", depress=False,)
                op.api = f"psy_active.s_proximity_master_allow = False"
                op.undo = translate("Remove Proximity Features")
                op.description = translate("There are more advanced features enabled for this scatter-system, however these are not available for Biome-Reader! Would you like to remove them?")

            if (s_push_used):
                s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

                s1.label(text=translate("Offset"),)
                ope = s2.row(align=True)
                op = ope.operator("scatter5.exec_line", text=translate("Remove"), icon="PANEL_CLOSE", depress=False,)
                op.api = f"psy_active.s_push_master_allow = False"
                op.undo = translate("Remove Offset Features")
                op.description = translate("There are more advanced features enabled for this scatter-system, however these are not available for Biome-Reader! Would you like to remove them?")
            
            if (s_wind_used):
                s1.separator(factor=sepa_small) ; s2.separator(factor=sepa_small)

                s1.label(text=translate("Wind"),)
                ope = s2.row(align=True)
                op = ope.operator("scatter5.exec_line", text=translate("Remove"), icon="PANEL_CLOSE", depress=False,)
                op.api = f"psy_active.s_wind_master_allow = False"
                op.undo = translate("Remove Wind Features")
                op.description = translate("There are more advanced features enabled for this scatter-system, however these are not available for Biome-Reader! Would you like to remove them?")
            
            #Separator 

            ui_templates.separator_box_in(box)

    return

def draw_pros_interface(self, layout, context):

    scat_scene, scat_ui, scat_win, emitter, psy_active, group_active = get_props()

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_tweak_pros", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_tweak_pros");BOOL_VALUE(1)
        panel_name=translate("Professional Workflow"),
        is_always_open=True,
        )
    if is_open:

        row = box.row()
        r1 = row.separator(factor=0.3)
        col = row.column()
        r3 = row.separator(factor=0.3)

        word_wrap(layout=col.box(), alignment="CENTER", active=True, max_char='auto', context=context, char_auto_sidepadding=0.85,
            string=translate("Get the workflow you need to become a pro!\n\nOur user-friendly interface is perfect for newbies, but our paid tool-kit for professionals is where the magic happens.\n\nWith advanced features, an efficient pipeline, and useful scattering operators, you'll be able to handle the most challenging projects with ease."),)
                
        col.separator(factor=0.75)

        ope = col.row()
        ope.scale_y = 1.2
        ope.operator("wm.url_open", text=translate("Upgrade Today"),).url = "https://blendermarket.com/products/scatter"

        #Separator 

        ui_templates.separator_box_in(box)

    return

def draw_group_beginner_masks(self,layout):

    scat_scene, scat_ui, scat_win, emitter, psy_active, group_active = get_props()

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_beginners_tweak_group_masks", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_beginners_tweak_group_masks");BOOL_VALUE(1)
        panel_name=translate("Group Masks"),
        )
    if is_open:
            
        ui_is_active = True 
        ui_is_active = active_check(group_active, s_category="s_gr_mask", prop=ui_is_active,)
        
        ########## ########## Vgroup

        tocol, is_toggled = ui_templates.bool_toggle(box, group_active, "s_gr_mask_vg_allow", 
            label=translate("Vertex-Group"), 
            icon="WPAINT_HLT", 
            active=ui_is_active,
            return_sublayout=True,
            )
        if is_toggled:

                mask_col = tocol.column(align=True)
                mask_col.separator(factor=0.35)

                exists = (group_active.s_gr_mask_vg_ptr!="")

                #mask pointer

                mask = mask_col.row(align=True)

                ptr = mask.row(align=True)
                ptr.alert = ( bool(group_active.s_gr_mask_vg_ptr) and not is_attr_surfs_shared(system=group_active, attr_type='vg', attr_name=group_active.s_gr_mask_vg_ptr,) )
                ptr.prop(group_active, f"s_gr_mask_vg_ptr", text="", icon="GROUP_VERTEX", placeholder=" "+translate("Vertex-Group"),)
                
                if (exists):
                    mask.prop(group_active, f"s_gr_mask_vg_revert", text="", icon="ARROW_LEFTRIGHT",)

                #paint or create operator

                op = mask.operator("scatter5.vg_quick_paint",
                    text="",
                    icon="BRUSH_DATA" if exists else "ADD",
                    depress=((bpy.context.mode=="PAINT_WEIGHT") and (getattr(bpy.context.object.vertex_groups.active,"name",'')==group_active.s_gr_mask_vg_ptr)),
                    )
                op.group_name = group_active.s_gr_mask_vg_ptr
                op.mode = "vg" 
                op.api = f"emitter.scatter5.particle_groups['{group_active.name}'].s_gr_mask_vg_ptr"

                tocol.separator(factor=1)

        #Separator 

        ui_templates.separator_box_in(box)
            
    return 


#    .oooooo.   oooo
#   d8P'  `Y8b  `888
#  888           888   .oooo.    .oooo.o  .oooo.o  .ooooo.   .oooo.o
#  888           888  `P  )88b  d88(  "8 d88(  "8 d88' `88b d88(  "8
#  888           888   .oP"888  `"Y88b.  `"Y88b.  888ooo888 `"Y88b.
#  `88b    ooo   888  d8(  888  o.  )88b o.  )88b 888    .o o.  )88b
#   `Y8bood8P'  o888o `Y888""8o 8""888P' 8""888P' `Y8bod8P' 8""888P'


class SCATTER5_PT_tweaking(bpy.types.Panel):

    bl_idname      = "SCATTER5_PT_tweaking"
    bl_label       = translate("Tweak")
    bl_category    = "USER_DEFINED" #will be replaced right before ui.__ini__.register()
    bl_space_type  = "VIEW_3D"
    bl_region_type = "UI"
    bl_context     = "" #nothing == enabled everywhere
    bl_order       = 3

    @classmethod
    def poll(cls, context,):
        if (context.scene.scatter5.emitter is None):
            return False
        if (context.mode not in ('OBJECT','PAINT_WEIGHT','PAINT_VERTEX','PAINT_TEXTURE','EDIT_MESH','EDIT_CURVE',)):
            return False
        return True 
        
    def draw_header(self, context):
        self.layout.label(text="", icon_value=cust_icon("W_BIOME"),)

    def draw_header_preset(self, context):
        emitter_header(self)

    def draw(self, context):
        layout = self.layout
        draw_tweaking_panel(self, layout, context,)

classes = (
        
    SCATTER5_UL_list_instances,
    SCATTER5_PT_tweaking,

    )

#if __name__ == "__main__":
#    register()