"""
• Script License: 

    This python script file is licensed under GPL 3.0
    
    This program is free software; you can redistribute it and/or modify it under 
    the terms of the GNU General Public License as published by the Free Software
    Foundation; either version 3 of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
    without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
    See the GNU General Public License for more details.
    
    See full license on 'https://www.gnu.org/licenses/gpl-3.0.en.html#license-text'

• Additonal Information: 

    The components in this archive are a mere aggregation of independent works. 
    The GPL-licensed scripts included here serve solely as a control and/or interface for 
    the Geo-Scatter geometry-node assets.

    The content located in the 'PluginFolder/non_gpl/' directory is NOT licensed under 
    the GPL. For details, please refer to the LICENSES.txt file within this folder.

    The non-GPL components and assets can function fully without the scripts and vice versa. 
    They do not form a derivative work, and are distributed together for user convenience.

    Redistribution, modification, or unauthorized use of the content in the 'non_gpl' folder,
    including .blend files or image files, is prohibited without prior written consent 
    from BD3D DIGITAL DESIGN, SLU.
        
• Trademark Information:

    Geo-Scatter® name & logo is a trademark or registered trademark of “BD3D DIGITAL DESIGN, SLU” 
    in the U.S. and/or European Union and/or other countries. We reserve all rights to this trademark. 
    For further details, please review our trademark and logo policies at “www.geoscatter.com/legal”. The 
    use of our brand name, logo, or marketing materials to distribute content through any non-official
    channels not listed on “www.geoscatter.com/download” is strictly prohibited. Such unauthorized use 
    falsely implies endorsement or affiliation with third-party activities, which has never been granted. We 
    reserve all rights to protect our brand integrity & prevent any associations with unapproved third parties.
    You are not permitted to use our brand to promote your unapproved activities in a way that suggests official
    endorsement or affiliation. As a reminder, the GPL license explicitly excludes brand names from the freedom,
    our trademark rights remain distinct and enforceable under trademark laws.

"""
# A product of “BD3D DIGITAL DESIGN, SLU”
# Authors:
# (c) 2024 Dorian Borremans

#####################################################################################################
#
# ooooo     ooo ooooo            .o.             .o8        .o8
# `888'     `8' `888'           .888.           "888       "888
#  888       8   888           .8"888.      .oooo888   .oooo888   .ooooo.  ooo. .oo.
#  888       8   888          .8' `888.    d88' `888  d88' `888  d88' `88b `888P"Y88b
#  888       8   888         .88ooo8888.   888   888  888   888  888   888  888   888
#  `88.    .8'   888        .8'     `888.  888   888  888   888  888   888  888   888
#    `YbodP'    o888o      o88o     o8888o `Y8bod88P" `Y8bod88P" `Y8bod8P' o888o o888o
#
#####################################################################################################


import bpy

import os
import platform 

from ... __init__ import addon_prefs

from .. resources.icons import cust_icon
from .. translations import translate
from .. resources import directories

from .. utils.str_utils import word_wrap
from .. utils.math_utils import square_area_repr, count_repr

from . import ui_templates


# ooo        ooooo            o8o                         .o.             .o8        .o8
# `88.       .888'            `"'                        .888.           "888       "888
#  888b     d'888   .oooo.   oooo  ooo. .oo.            .8"888.      .oooo888   .oooo888   .ooooo.  ooo. .oo.
#  8 Y88. .P  888  `P  )88b  `888  `888P"Y88b          .8' `888.    d88' `888  d88' `888  d88' `88b `888P"Y88b
#  8  `888'   888   .oP"888   888   888   888         .88ooo8888.   888   888  888   888  888   888  888   888
#  8    Y     888  d8(  888   888   888   888        .8'     `888.  888   888  888   888  888   888  888   888
# o8o        o888o `Y888""8o o888o o888o o888o      o88o     o8888o `Y8bod88P" `Y8bod88P" `Y8bod8P' o888o o888o


def draw_addon(self, layout, context,):
    """drawing dunction of AddonPrefs class, stored in properties"""

    #WARNING: Modifying the texts or code below does not in any shape or form change our legal conditions, find the conditions on www.geoscatter.com/legal 
    
    row = layout.row()
    r1 = row.separator()
    col = row.column()
    r3 = row.separator()
        
    #Enter Manager 

    col.label(text=translate("Enter The Plugin Manager."),)
    enter = col.row()
    enter.scale_y = 1.5
    enter.operator("scatter5.impost_addonprefs", text=translate("Enter Interface"), icon_value=cust_icon("W_BIOME"),).state = True

    #Write license block 

    col.separator(factor=1.5)
    license_layout = col

    from ... __init__ import bl_info
    plugin_name = bl_info["name"]

    #License Agreement 
    
    license_layout.label(text=f"{plugin_name} Comprised Licenses:",)
    boxcol = license_layout.column(align=True)
    box = boxcol.box()
    text = f"The {plugin_name} product aggregate is comprised of three distinct and separate components comprised of their own distinct licenses:\n1) A series of python scripts stored in “/gpl_script/” released under the GNU-GPL 3.0 used for drawing an user interface. 2) A non-software geometry-node nodetree asset called the “GEO-SCATTER ENGINE” stored in “/non_gpl/blends/enging.blend” with a EULA license similar to Royalty free. 3). Icons stored in “/non_gpl/icons/” comprised of various licenses.\nBy using our {plugin_name} product, you, the user, agree to the terms and conditions of all comprised licenses.\nOnly “GEO-SCATTER ENGINE” licenses downloaded from the official source listed on “www.geoscatter.com/download” are legitimate. Compared to the Royalty Free license, the “GEO-SCATTER ENGINE” end user license agreement provides an additional advantage by allowing users to freely share Blender scenes containing the nodetree, while also placing restrictions on how users may interact with our engine nodetree through the usage of scripts or plugins.\nPlease read all additional LICENSES.txt files located within our products for more information and the legal information on “www.geoscatter.com/legal”."
    word_wrap(layout=box, max_char='auto', context=context, char_auto_sidepadding=0.99, alert=False, active=False, scale_y=0.81, string=text,)
    boxl = boxcol.box()
    boxllbl = boxl.row()
    boxllbl.alignment = "CENTER"
    boxllbl.active = False
    boxllbl.operator("wm.url_open", text="For more precisions, consult “www.geoscatter.com/legal”", emboss=False, ).url = "www.geoscatter.com/legal"

    #License Variation 
    
    match directories.engine_license:
        
        case "":
            licsc_tit, licsc_txt = "Geo-Scatter® Engine: No License Found.", "Hello. The script you are currently using sole purpose is to be the interface of our Geometry-node scatter asset called “GEO-SCATTER ENGINE”. Both assets and script can work fully independently. Without our 'engine.blend' present, the interface will work fine, you simply won't be able to communicate with our asset. Note that you can do that manually if you'd like. It looks like you detain no licenses for our “GEO-SCATTER ENGINE”. Please read the full EULA regarding our “GEO-SCATTER ENGINE” asset on “www.geoscatter.com/legal” make sure this engine is only downloaded from one of our recognized sources listed on “www.geoscatter.com/download” any other sources aren't legit."
            if ((licsc_tit is not None) and (licsc_txt is not None)):
                license_layout.separator(factor=1.5)
                license_layout.label(text=licsc_tit,)
                boxcol = license_layout.column(align=True)
                box = boxcol.box()
                word_wrap(layout=box, max_char='auto', context=context, char_auto_sidepadding=0.99, alert=False, active=False, scale_y=0.81, string=licsc_txt,)
                boxl = boxcol.box()
                boxllbl = boxl.row()
                boxllbl.alignment = "CENTER"
                boxllbl.active = False
                boxllbl.operator("wm.url_open", text="Get our asset on “www.geoscatter.com”", emboss=False, ).url = "www.geoscatter.com"
                        
        case str():
            licsc_tit, licsc_txt = "Geo-Scatter® Engine Biome-Reader Individual License:", "The “Individual” license for “GEO-SCATTER ENGINE” is a non-transferable license that grants a single user the right to use the “GEO-SCATTER ENGINE” on any device they own for personal or commercial purposes. This license grants the licensee the permission to interact with our engine through the use of our official interface script." #REPLACED_ON_SHIPPING
            if ((licsc_tit is not None) and (licsc_txt is not None)):
                license_layout.separator(factor=1.5)
                license_layout.label(text=licsc_tit,)
                boxcol = license_layout.column(align=True)
                box = boxcol.box()
                word_wrap(layout=box, max_char='auto', context=context, char_auto_sidepadding=0.99, alert=False, active=False, scale_y=0.81, string=licsc_txt,)
                boxl = boxcol.box()
                boxllbl = boxl.row()
                boxllbl.alignment = "CENTER"
                boxllbl.active = False
                boxllbl.operator("wm.url_open", text="This agreement is available on “www.geoscatter.com/legal”", emboss=False, ).url = "www.geoscatter.com/legal"

    #Trademark Info 
    
    license_layout.separator(factor=1.5)
    license_layout.label(text=f"Trademark Information:",)
    boxcol = license_layout.column(align=True)
    box = boxcol.box()
    text = f"Note that the Geo-Scatter® name & logo is a trademark or registered trademark of “BD3D DIGITAL DESIGN, SLU” in the U.S. and/or European Union and/or other countries. We reserve all rights to this trademark. For further details, please review our trademark and logo policies at “www.geoscatter.com/legal”. The use of our brand name, logo, or marketing materials to distribute content through any non-official channels not listed on “www.geoscatter.com/download” is strictly prohibited. Such unauthorized use falsely implies endorsement or affiliation with third-party activities, which has never been granted. We reserve all rights to protect our brand integrity & prevent any associations with unapproved third parties. You are not permitted to use our brand to promote your unapproved activities in a way that suggests official endorsement or affiliation. As a reminder, the GPL license explicitly excludes brand names from the freedom, our trademark rights remain distinct and enforceable under trademark laws."
    word_wrap(layout=box, max_char='auto', context=context, char_auto_sidepadding=0.99, alert=False, active=False, scale_y=0.81, string=text,)
    boxl = boxcol.box()
    boxllbl = boxl.row()
    boxllbl.alignment = "CENTER"
    boxllbl.active = False
    boxllbl.operator("wm.url_open", text="Visit “www.geoscatter.com/legal”", emboss=False, ).url = "www.geoscatter.com/legal"
    
    #Contact Info
    
    license_layout.separator(factor=1.5)
    license_layout.label(text="Contact Information:",)
    boxcol = license_layout.column(align=True)
    box = boxcol.box()
    text = "If you have any inquiries or questions, you may contact us via “contact@geoscatter.com” or through our diverse social medial lised on “www.geoscatter.com” or listed within this very plugin."
    word_wrap(layout=box, max_char='auto', context=context, char_auto_sidepadding=0.99, alert=False, active=False, scale_y=0.81, string=text,)
    boxl = boxcol.box()
    boxllbl = boxl.row()
    boxllbl.alignment = "CENTER"
    boxllbl.active = False
    boxllbl.operator("wm.url_open", text="Visit “www.geoscatter.com”", emboss=False, ).url = "www.geoscatter.com"

    #Extend Info
    
    disclaimer = col.column()
    disclaimer.separator(factor=0.7)
    disclaimer.active = True
    word_wrap(layout=disclaimer, max_char='auto', context=context, char_auto_sidepadding=0.99, alert=False, active=True, scale_y=0.91, alignment='LEFT',
        string="*Extend or zoom this interface if texts are not readable.",)

    col.separator(factor=2)

    return None


# ooooo   ooooo  o8o   o8o                     oooo         o8o
# `888'   `888'  `"'   `"'                     `888         `"'
#  888     888  oooo  oooo  .oooo.    .ooooo.   888  oooo  oooo  ooo. .oo.    .oooooooo
#  888ooooo888  `888  `888 `P  )88b  d88' `"Y8  888 .8P'   `888  `888P"Y88b  888' `88b
#  888     888   888   888  .oP"888  888        888888.     888   888   888  888   888
#  888     888   888   888 d8(  888  888   .o8  888 `88b.   888   888   888  `88bod8P'
# o888o   o888o o888o  888 `Y888""8o `Y8bod8P' o888o o888o o888o o888o o888o `8oooooo.
#                      888                                                   d"     YD
#                  .o. 88P                                                   "Y88888P'
#                  `Y888P

def addonpanel_overridedraw(self, context,):
    """Impostor Main"""

    layout = self.layout

    scat_win = bpy.context.window_manager.scatter5

    #Prefs
    match scat_win.category_manager:
        
        case 'prefs':
            draw_add_prefs(self, layout)
            
        case 'library':
            from . ui_biome_library import draw_library_grid
            draw_library_grid(self, layout, context,)

        case 'market':
            from . ui_biome_library import draw_online_grid
            draw_online_grid(self, layout, context,)
            

    return None

            
def addonheader_overridedraw(self, context):
    """Impostor Header"""

    layout = self.layout

    scat_win = bpy.context.window_manager.scatter5
    scat_scene = context.scene.scatter5
    emitter = scat_scene.emitter
    
    from ... __init__ import bl_info
    plugin_name = bl_info["name"]
    
    row = layout.row(align=True)
    row.template_header()

    scat = row.row(align=True)
    scat.scale_x = 1.1
    scat.menu("SCATTER5_MT_manager_header_menu_scatter", text=plugin_name, icon_value=cust_icon("W_BIOME"),)

    match scat_win.category_manager:

        case 'library':
            row.menu("SCATTER5_MT_manager_header_menu_interface", text=translate("Interface"),)
            row.menu("SCATTER5_MT_manager_header_menu_open", text=translate("File"),)
            popover = row.row(align=True)
            popover.emboss = "NONE"
            popover.popover(panel="SCATTER5_PT_creation_operator_load_biome", text="Settings",)

        case 'lister_large':
            row.menu("SCATTER5_MT_manager_header_menu_interface", text=translate("Interface"),)

        case 'lister_stats':
            row.menu("SCATTER5_MT_manager_header_menu_interface", text=translate("Interface"),)

        case 'market':
            row.menu("SCATTER5_MT_manager_header_menu_interface", text=translate("Interface"),)
            row.menu("SCATTER5_MT_manager_header_menu_open", text=translate("File"),)

        case 'prefs':
            row.menu("USERPREF_MT_save_load", text=translate("Preferences"),)

    layout.separator_spacer()

    if (scat_win.category_manager!="prefs"):
        
        emit = layout.row(align=True)
        
        #helper for noobs..
        if (emitter is None):
            emitlbl = emit.row(align=True)
            emitlbl.alert = True
            emitlbl.label(text=translate("Pick an Emitter →"),)
        
        kwargs = {}
        if (emitter is None):
            kwargs["icon_value"] = cust_icon("W_EMITTER")
        elif (emitter.library):
            kwargs["icon"] = "LINKED"
            
        emit.prop(scat_scene, "emitter",text="", **kwargs)

    exit = layout.row()
    exit.alert = True
    exit.operator("scatter5.impost_addonprefs",text=translate("Exit"),icon='PANEL_CLOSE').state = False

    return None


def addonnavbar_overridedraw(self, context):
    """importor T panel"""

    layout = self.layout

    from ... __init__ import blend_prefs
    scat_data  = blend_prefs()
    scat_win   = context.window_manager.scatter5
    scat_scene = context.scene.scatter5
    emitter = scat_scene.emitter

    #Close if user is dummy 

    if (not context.space_data.show_region_header):
        exit = layout.column()
        exit.alert = True
        exit.operator("scatter5.impost_addonprefs",text=translate("Exit"),icon='PANEL_CLOSE').state = False
        exit.scale_y = 1.8
        return None

    #Draw main categories 

    enum = layout.column()
    enum.scale_y = 1.3
    enum.prop(scat_win,"category_manager",expand=True)

    layout.separator(factor=0.3)
    layout.separator(type="LINE")

    #Per category T panel

    match scat_win.category_manager:
        
        case 'library':

            lbl = layout.row()
            lbl.active = False
            lbl.label(text=translate("Navigation"),)

            row = layout.row(align=True)
            row.scale_y = 1.0
            row.prop(scat_win,"library_search",icon="VIEWZOOM",text="") 
            row.prop(scat_win,"library_filter_favorite",icon_value=cust_icon("W_AFFINITY"),text="") 

            layout.separator(factor=0.33)

            wm = bpy.context.window_manager
            navigate = layout.column(align=True)
            navigate.scale_y = 1.0
            navigate.template_list("SCATTER5_UL_folder_navigation", "", wm.scatter5, "folder_navigation", wm.scatter5, "folder_navigation_idx",rows=15,)

            elements_count = 0 
            if (len(scat_win.folder_navigation)!=0):
                elements_count = scat_win.folder_navigation[scat_win.folder_navigation_idx].elements_count

            indic = navigate.box()
            indic.scale_y = 1.0
            indic.label(text=f'{elements_count} {translate("Elements in Folder")}')
            
            # layout.separator()

            # lbl = layout.row()
            # lbl.active = False
            # lbl.label(text=translate("Need More?"),)

            # row = layout.row(align=True)
            # row.scale_y = 1.0
            # row.operator("scatter5.exec_line",text=translate("Get Biomes"), icon="URL",).api = 'scat_win.category_manager = "market" ; bpy.context.area.tag_redraw()'

            # lbl = layout.row()
            # lbl.active = False
            # lbl.label(text=translate("Install a Scatpack?"),)

            # row = layout.row(align=True)
            # row.scale_y = 1.0
            # row.operator("scatter5.install_package", text=translate("Install a Pack"), icon="NEWFOLDER")

        case 'market':

            lbl = layout.row()
            lbl.active = False
            lbl.label(text=translate("All Biomes"),)

            row = layout.row(align=True)
            row.scale_y = 1.0
            row.operator("wm.url_open",text=translate("Visit Website"),icon="URL").url="https://geoscatter.com/biomes"

            lbl = layout.row()
            lbl.active = False
            lbl.label(text=translate("Share your Pack"),)

            row = layout.row(align=True)
            row.scale_y = 1.0
            row.operator("wm.url_open",text=translate("Contact Us"),icon="URL").url="https://discord.com/invite/F7ZyjP6VKB"

            lbl = layout.row()
            lbl.active = False
            lbl.label(text=translate("Refresh Page"),)

            row = layout.row(align=True)
            row.scale_y = 1.0
            row.operator("scatter5.fetch_content_from_git",text=translate("Refresh"), icon="FILE_REFRESH")

        case 'lister_large':

            if (emitter is not None):

                nbr = len(emitter.scatter5.get_psys_selected(all_emitters=scat_data.factory_alt_selection_method=="all_emitters"))

                # lbl = layout.row()
                # lbl.active = False
                # lbl.label(text=translate("Batch Optimize"),)
                #
                # row = layout.row(align=True)
                # row.scale_y = 1.00
                # row.operator("scatter5.batch_optimization",text=translate("Set Optimizations"),icon="MEMORY")

                lbl = layout.row()
                lbl.active = False
                lbl.label(text=translate("Bounding-Box"),)

                row = layout.row(align=True)
                row.scale_y = 1.0
                row.operator("scatter5.batch_bounding_box",text=translate("Set Bounds"),icon="CUBE").pop_dialog = True

                lbl = layout.row()
                lbl.active = False
                lbl.label(text=translate("Alt Behavior")+f" [{nbr}]",)
                
                row = layout.row(align=True)
                if (scat_data.factory_alt_allow):
                      row.scale_y = 1.1
                      row.prop(scat_data,"factory_alt_selection_method",text="",)
                else: row.prop(scat_data,"factory_alt_allow",text=translate("Enable Alt"), icon="BLANK1",)

        case 'lister_stats':

            if (emitter is not None):

                lbl = layout.row()
                lbl.active = False
                lbl.label(text=translate("Estimate Count"),)

                row = layout.row()
                row.scale_y = 1.0
                op = row.operator("scatter5.exec_line",text=translate("Refresh"),icon="FILE_REFRESH",)
                op.api = f"[ ( p.get_scatter_count(state='render',) , p.get_scatter_count(state='viewport') ) for p in scat_scene.get_all_psys(search_mode='all', also_linked=True)] ; [a.tag_redraw() for a in bpy.context.screen.areas]"
                op.description = translate("Compute the instance-count statistics of every single scatter-system in your scene")

                lbl = layout.row()
                lbl.active = False
                lbl.label(text=translate("Estimate Area"),)

                row = layout.row()
                row.scale_y = 1.0
                op = row.operator("scatter5.exec_line",text=translate("Refresh"),icon="FILE_REFRESH",)
                op.api = f"[ p.get_surfaces_square_area(evaluate='recalculate', eval_modifiers=True, get_selection=False,) for p in scat_scene.get_all_psys(search_mode='all', also_linked=True)] ; [a.tag_redraw() for a in bpy.context.screen.areas]"
                op.description = translate("Compute the square area statistics of every single scatter-surface in your scene")

        case 'prefs':
            
                lbl = layout.row()
                lbl.active = False
                lbl.label(text=translate("Export Settings"),)

                row = layout.row()
                row.scale_y = 1.0
                op = row.operator("scatter5.export_addon_settings",text=translate("Export"),icon="FILE_CACHE",)
                
                lbl = layout.row()
                lbl.active = False
                lbl.label(text=translate("Import Settings"),)

                row = layout.row()
                row.scale_y = 1.0
                op = row.operator("scatter5.import_addon_settings",text=translate("Import"),icon="FILE_CACHE",)

    return None


# 88  88 88  88888    db     dP""b8 88  dP      dP"Yb  88""Yb 888888 88""Yb    db    888888  dP"Yb  88""Yb
# 88  88 88     88   dPYb   dP   `" 88odP      dP   Yb 88__dP 88__   88__dP   dPYb     88   dP   Yb 88__dP
# 888888 88 o.  88  dP__Yb  Yb      88"Yb      Yb   dP 88"""  88""   88"Yb   dP__Yb    88   Yb   dP 88"Yb
# 88  88 88 "bodP' dP""""Yb  YboodP 88  Yb      YbodP  88     888888 88  Yb dP""""Yb   88    YbodP  88  Yb


class SCATTER5_OT_impost_addonprefs(bpy.types.Operator):
    """Monkey patch drawing code of addon preferences to our own code, temporarily"""

    bl_idname      = "scatter5.impost_addonprefs"
    bl_label       = ""
    bl_description = translate("replace/restore native blender preference ui with a custom scatter manager ui")

    state : bpy.props.BoolProperty()

    Status = False
    AddonPanel_OriginalDraw = None
    AddonNavBar_OriginalDraw = None
    AddonHeader_OriginalDraw = None

    def panel_hijack(self):
        """register impostors"""

        cls = type(self)
        if (cls.Status==True):
            return None

        #show header just in case user hided it (show/hide header on 'PREFERENCE' areas)

        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if (area.type=='PREFERENCES'):
                    for space in area.spaces:
                        if (space.type=='PREFERENCES'):
                            space.show_region_header = True

        #Save Original Class Drawing Function in global , and replace their function with one of my own 

        cls.AddonPanel_OriginalDraw = bpy.types.USERPREF_PT_addons.draw
        bpy.types.USERPREF_PT_addons.draw = addonpanel_overridedraw
            
        cls.AddonNavBar_OriginalDraw = bpy.types.USERPREF_PT_navigation_bar.draw
        bpy.types.USERPREF_PT_navigation_bar.draw = addonnavbar_overridedraw
        
        cls.AddonHeader_OriginalDraw = bpy.types.USERPREF_HT_header.draw
        bpy.types.USERPREF_HT_header.draw = addonheader_overridedraw
        
        cls.Status=True

        return None

    def panel_restore(self):
        """restore and find original drawing classes"""

        cls = type(self)
        if (cls.Status==False):
            return None

        #restore original drawing code 
        
        bpy.types.USERPREF_PT_addons.draw = cls.AddonPanel_OriginalDraw
        cls.AddonPanel_OriginalDraw = None 

        bpy.types.USERPREF_PT_navigation_bar.draw = cls.AddonNavBar_OriginalDraw
        cls.AddonNavBar_OriginalDraw = None 

        bpy.types.USERPREF_HT_header.draw = cls.AddonHeader_OriginalDraw
        cls.AddonHeader_OriginalDraw = None 

        #Trigger Redraw, otherwise some area will be stuck until user put cursor 

        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if (area.type=='PREFERENCES'):
                    area.tag_redraw()
                    
        cls.Status=False

        return None

    def execute(self, context):
        
        match self.state:
            case True:
                self.panel_hijack()
            case False:
                self.panel_restore()

        return{'FINISHED'}


# oooooooooo.                                        ooooo     ooo                              ooooooooo.                       .o88o.
# `888'   `Y8b                                       `888'     `8'                              `888   `Y88.                     888 `"
#  888      888 oooo d8b  .oooo.   oooo oooo    ooo   888       8   .oooo.o  .ooooo.  oooo d8b   888   .d88' oooo d8b  .ooooo.  o888oo   .oooo.o
#  888      888 `888""8P `P  )88b   `88. `88.  .8'    888       8  d88(  "8 d88' `88b `888""8P   888ooo88P'  `888""8P d88' `88b  888    d88(  "8
#  888      888  888      .oP"888    `88..]88..8'     888       8  `"Y88b.  888ooo888  888       888          888     888ooo888  888    `"Y88b.
#  888     d88'  888     d8(  888     `888'`888'      `88.    .8'  o.  )88b 888    .o  888       888          888     888    .o  888    o.  )88b
# o888bood8P'   d888b    `Y888""8o     `8'  `8'         `YbodP'    8""888P' `Y8bod8P' d888b     o888o        d888b    `Y8bod8P' o888o   8""888P'



def draw_add_prefs(self, layout):
    
    #limit panel width

    row = layout.row()
    row.alignment="LEFT"
    main = row.column()
    main.alignment = "LEFT"

    draw_add_packs(self,main)
    ui_templates.separator_box_out(main)

    draw_add_environment(self,main)
    ui_templates.separator_box_out(main)

    draw_add_lang(self,main)
    ui_templates.separator_box_out(main)

    draw_add_fetch(self,main)
    ui_templates.separator_box_out(main)
    
    draw_add_paths(self,main)
    ui_templates.separator_box_out(main)
    

    draw_add_dev(self,main)
    ui_templates.separator_box_out(main)
            
    for i in range(10):
        layout.separator_spacer()

    return None 


def draw_add_packs(self,layout):

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_add_packs", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_add_packs");BOOL_VALUE(1)
        panel_icon="NEWFOLDER", 
        panel_name=translate("Install a Package"),
        popover_uilayout_context_set="ui_add_packs",
        )
    if is_open:

            row = box.row()
            row.separator(factor=0.3)
            col = row.column()
            row.separator(factor=0.3)

            rwoo = col.row()
            rwoo.operator("scatter5.install_package", text=translate("Install a Package"), icon="NEWFOLDER")
            scatpack = rwoo.row()
            scatpack.operator("scatter5.exec_line", text=translate("Find Biomes Online"),icon_value=cust_icon("W_SUPERMARKET")).api = "scat_win.category_manager='market' ; bpy.ops.scatter5.tag_redraw()"

            ui_templates.separator_box_in(box)

    return None


def draw_add_fetch(self,layout):

    sysprefs = bpy.context.preferences.system
    online_access = bpy.app.online_access

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_add_fetch", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_add_fetch");BOOL_VALUE(1)
        panel_icon="URL", 
        panel_name=translate("Scatpack Previews Fetch"),
        )
    if is_open:

            row = box.row()
            row.separator(factor=0.3)
            col = row.column()
            row.separator(factor=0.3)
                        
            ui_templates.bool_toggle(col, sysprefs, "use_online_access", 
                label=translate("Allow online access"), 
                icon="INTERNET" if sysprefs.use_online_access else "INTERNET_OFFLINE", 
                use_layout_left_spacer=False,
                )
            
            col.separator()
                                            
            ui_templates.bool_toggle(col, addon_prefs(), "fetch_automatic_allow", 
                label=translate("Automatically fetch Scatpacks previews"), 
                icon="FILE_REFRESH", 
                use_layout_left_spacer=False,
                active=online_access,
                )
            
            col.separator()
            row = col.row()
            
            subr = row.row()
            subr.active = addon_prefs().fetch_automatic_allow and online_access
            subr.prop(addon_prefs(), "fetch_automatic_daycount", text=translate("Fetch every n Day"),)
            
            subr = row.row()
            subr.operator("scatter5.fetch_content_from_git", text=translate("Refresh Online Previews"), icon="FILE_REFRESH")
            subr.active = online_access

            ui_templates.separator_box_in(box)
    
    return None

    
def draw_add_browser(self,layout):

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_add_browser", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_add_browser");BOOL_VALUE(1)
        panel_icon="ASSET_MANAGER", 
        panel_name=translate("Asset Browser Convert"),
        popover_info="SCATTER5_PT_docs", 
        popover_uilayout_context_set="ui_add_browser",
        )
    if is_open:

            row = box.row()
            row.separator(factor=0.3)
            col = row.column()
            row.separator(factor=0.3)
            
            col.operator("scatter5.make_asset_library", text=translate("Convert blend(s) to Asset-Browser Format"), icon="FILE_BLEND",)
                
            col.separator(factor=0.5)
            word_wrap(layout=col, max_char=70, alert=False, active=True, string=translate("Warning, this operator will quit this session to sequentially open all blends and mark their asset(s). Please do not interact with the interface until the task is finished.."),)

            ui_templates.separator_box_in(box)
    
    return None


def draw_clean_data(self,layout):

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="clean_data", #INSTRUCTION:REGISTER:UI:BOOL_NAME("clean_data");BOOL_VALUE(1)
        panel_icon="MESH_DATA", 
        panel_name=translate("Clanse Data"),
        #popover_info="SCATTER5_PT_docs", 
        #popover_uilayout_context_set="clean_data",
        )
    if is_open:

            row = box.row()
            row.separator(factor=0.3)
            col = row.column()
            row.separator(factor=0.3)
            
            col.operator("scatter5.clean_unused_import_data", text=translate("Delete unused imports"), icon="TRASH",)
            col.separator(factor=0.5)
            col.operator("outliner.orphans_purge", text=translate("Purge orphans data"), icon="ORPHAN_DATA",).do_recursive = True
            col.separator(factor=0.5)
            col.operator("scatter5.fix_nodetrees", text=translate("Fix all Scatter-Objects/Engines"), icon="TOOL_SETTINGS",).force_update = True
            
            ui_templates.separator_box_in(box)
    
    return None


def draw_add_lang(self,layout):

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_add_lang", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_add_lang");BOOL_VALUE(1)
        panel_icon="WORLD_DATA", 
        panel_name=translate("Languages"),
        )
    if is_open: 

            scat_addon = addon_prefs()

            row = box.row()
            row.separator(factor=0.3)
            col = row.column()
            row.separator(factor=0.3)
            
            ope = col.row()
            ope.prop(scat_addon,"language",text="")

            if (scat_addon.language!="English"):
                
                col.separator(factor=0.7)
                rwoo = col.row()
                word_wrap(layout=rwoo, max_char=65, active=True, string=translate("Translations are only applied when booting up blender. Please quit and restart blender to apply the changes!"),)
                
            ui_templates.separator_box_in(box)

    return None 


def draw_add_npanl(self,layout):

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_add_npanl", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_add_npanl");BOOL_VALUE(1)
        panel_icon="MENU_PANEL", 
        panel_name=translate("N Panel Name"),
        )
    if is_open:

            row = box.row()
            row.separator(factor=0.3)
            col = row.column()
            row.separator(factor=0.3)

            ope = col.row()
            ope.alert = (addon_prefs().tab_name in (""," ","  "))
            ope.prop(addon_prefs(),"tab_name",text="")
            
            ui_templates.separator_box_in(box)

    return None


def draw_add_paths(self,layout):

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_add_paths", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_add_paths");BOOL_VALUE(1)
        panel_icon="FILEBROWSER", 
        panel_name=translate("Scatter-Library Location"),
        popover_info="SCATTER5_PT_docs", 
        popover_uilayout_context_set="ui_add_paths",
        )
    if is_open:

            row = box.row()
            row.separator(factor=0.3)
            col = row.column()
            row.separator(factor=0.3)
                
            is_library = os.path.exists(addon_prefs().library_path)
            is_biomes  = os.path.exists(os.path.join(addon_prefs().library_path,"_biomes_"))
            is_presets = os.path.exists(os.path.join(addon_prefs().library_path,"_presets_"))
            is_bitmaps = os.path.exists(os.path.join(addon_prefs().library_path,"_bitmaps_"))

            colc = col.column(align=True)

            pa = colc.row(align=True)
            pa.alert = not is_library
            pa.prop(addon_prefs(),"library_path",text="")

            if ( False in (is_library, is_biomes, is_presets,) ):

                colc.separator(factor=0.7)

                warn = colc.column(align=True)
                warn.alignment = "CENTER"
                warn.scale_y = 0.9
                warn.alert = True
                word_wrap(layout=warn, alert=True, max_char=65, active=True, icon="ERROR", string=translate("There are problem(s) with the location you have chosen\n"),)
                
                if (not is_library):
                    warn.label(text=translate("-The following paths don't exist"))
                if (not is_biomes):
                    warn.label(text="-'_biomes_' "+translate("Directory Not Found"))
                if (not is_presets):
                    warn.label(text="-'_biomes_' "+translate("Directory Not Found"))
                if (not is_bitmaps):
                    warn.label(text="-'_biomes_' "+translate("Directory Not Found"))

                word_wrap(layout=warn, alert=True, max_char=65, active=True, icon="BLANK1", string=translate("\nAre you sure you chose the path of a Scatter-Library? Please note that this path is not where you're supposed to add a biome environment path, the settings related to biomes are right above.\nBecause the library is invalid, we will use the default library location instead"),)

            if all([ is_library, is_biomes, is_presets, is_bitmaps]) and (directories.lib_library!=addon_prefs().library_path):
                colc.separator(factor=0.7)

                warn = colc.column(align=True)
                warn.scale_y = 0.85
                warn.label(text=translate("Chosen Library is Valid, Please save your addonprefs and restart blender."),icon="CHECKMARK")

            col.separator()

            row = col.row()
            col1 = row.column()
            col1.operator("scatter5.reload_biome_library", text=translate("Reload Library"), icon="FILE_REFRESH")
            col1.operator("scatter5.reload_preset_gallery", text=translate("Reload Presets"), icon="FILE_REFRESH")
            col1.operator("scatter5.dummy", text=translate("Reload Images"), icon="FILE_REFRESH")

            col2 = row.column()
            col2.operator("scatter5.open_directory", text=translate("Open Library"),icon="FOLDER_REDIRECT").folder = directories.lib_library
            col2.operator("scatter5.open_directory", text=translate("Open Default Library"),icon="FOLDER_REDIRECT").folder = directories.lib_default
            col2.operator("scatter5.open_directory", text=translate("Open Blender Data"),icon="FOLDER_REDIRECT").folder = directories.blender_version
            
            ui_templates.separator_box_in(box)

    return None 


def draw_add_environment(self,layout):

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_add_environment", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_add_environment");BOOL_VALUE(1)
        panel_icon="LONGDISPLAY", 
        panel_name=translate("Biomes Environment Paths"),
        popover_gearwheel="SCATTER5_PT_add_environment",
        popover_info="SCATTER5_PT_docs", 
        popover_uilayout_context_set="ui_add_environment",
        )
    if is_open:

            scat_addon = addon_prefs()
            
            row = box.row()
            row.separator(factor=0.3)
            col = row.column()
            row.separator(factor=0.3)

            ui_templates.bool_toggle(col, scat_addon, "blend_environment_scatterlib_allow",
                label=translate("Search for blend(s) first in your Biome-Library"),
                icon="W_BIOME",
                use_layout_left_spacer=False,
                )
            if (scat_addon.blend_environment_scatterlib_allow):

                col.separator(factor=0.5)
                alcol = col.box().column()

                if (not os.path.exists(directories.lib_library)):
                    row = alcol.row(align=True)
                    row.active = False
                    row.label(text=translate("No Path(s) Found"))
                else:
                    row = alcol.row()
                    row.enabled = False
                    row.prop(scat_addon,"library_path", text="")

                col.separator(factor=0.5)
                
            col.separator()
            
            ui_templates.bool_toggle(col, scat_addon, "blend_environment_path_allow",
                label=translate("Search for blend(s) in priority in given paths"),
                icon="FILE_BLEND",
                use_layout_left_spacer=False,
                )
            if (scat_addon.blend_environment_path_allow):

                col.separator(factor=0.5)

                alcocol = col.column(align=True)
                alcol = alcocol.box().column()

                #property interface

                if (len(scat_addon.blend_environment_paths)==0):
                    row = alcol.row(align=True)
                    row.active = False
                    row.label(text=translate("No Path(s) Found"))
                else:
                    for l in scat_addon.blend_environment_paths:

                        row = alcol.row(align=True)

                        path = row.row(align=True)
                        path.alert = not os.path.exists(l.blend_folder)
                        path.prop(l, "blend_folder", text="", )

                        #find index for remove operator
                        for i,p in enumerate(scat_addon.blend_environment_paths):
                            if (p.name==l.name):                        
                                op = row.operator("scatter5.exec_line", text="", icon="TRASH",)
                                op.api = f"addon_prefs().blend_environment_paths.remove({i})"
                                break

                        continue
                    
                #add button 

                addnew = alcocol.row(align=True)
                addnew.scale_y = 0.85
                op = addnew.operator("scatter5.exec_line", text=translate("Add New Path"), icon="ADD", depress=False)
                op.api = "n = addon_prefs().blend_environment_paths.add() ; n.name=str(len(addon_prefs().blend_environment_paths)-1)"
                op.description = translate("Add a path in which the biome system will search for blends!")

                col.separator(factor=1.0)

            col.separator()
            
            ui_templates.bool_toggle(col, scat_addon, "blend_environment_path_asset_browser_allow", 
                label=translate("Search for blend(s) in your blender asset-browser"),
                icon="ASSET_MANAGER",
                use_layout_left_spacer=False,
                )
            if (scat_addon.blend_environment_path_asset_browser_allow):

                col.separator(factor=0.5)
                
                alcocol = col.column(align=True)
                alcol = alcocol.box().column()

                if (len(bpy.context.preferences.filepaths.asset_libraries)==0):
                    row = alcol.row(align=True)
                    row.active = False
                    row.label(text=translate("No Path(s) Found"))
                else:
                    for l in bpy.context.preferences.filepaths.asset_libraries:

                        row = alcol.row()
                        row.enabled = False
                        row.alert = not os.path.exists(l.path)
                        row.prop(l,"path", text="")

                        continue

                #add button 
                addnew = alcocol.row(align=True)
                addnew.scale_y = 0.85
                addnew.operator("preferences.asset_library_add", text=translate("Add New Asset-Library"), icon="ADD", depress=False)

                col.separator(factor=1.0)

            ui_templates.separator_box_in(box)

    return None


def draw_add_dev(self,layout):

    box, is_open = ui_templates.box_panel(layout, 
        panelopen_propname="ui_add_dev", #INSTRUCTION:REGISTER:UI:BOOL_NAME("ui_add_dev");BOOL_VALUE(1)
        panel_icon="CONSOLE", 
        panel_name=translate("Debugging"),
        )
    if is_open:

            ui_templates.bool_toggle(box, addon_prefs(), "debug_interface", label="Debug interface", icon="CONSOLE", )
            ui_templates.bool_toggle(box, addon_prefs(), "debug", label="Debug prints", icon="CONSOLE", )
            ui_templates.bool_toggle(box, addon_prefs(), "debug_depsgraph", label="Debug depsgraph prints", icon="CONSOLE", active=addon_prefs().debug,)

            row = box.row()
            row.separator(factor=0.3)
            col = row.column()
            row.separator(factor=0.3)

            col.operator("scatter5.fix_nodetrees", text=translate("Fix all Scatter-Objects/Engines"), icon="TOOL_SETTINGS",).force_update = True
            
            col.separator(factor=0.5)
            col.operator("scatter5.icons_reload", text="Reload plugin icons", icon="TOOL_SETTINGS",)

            col.separator(factor=0.5)
            col.operator("scatter5.exec_line", text="Check for notifications", icon="TOOL_SETTINGS",).api = "check_for_notifications()"

            col.separator(factor=0.5)
            col.operator("scatter5.exec_line", text="Cleanup 'Geo-Scatter' collection", icon="TOOL_SETTINGS",).api = "cleanup_scatter_collections()"

            col.separator(factor=0.5)
            col.operator("scatter5.exec_line", text="Print uuid's repo content", icon="TOOL_SETTINGS",).api = "print('') ; print('Print uuids_repository') ; [print(' «',itm.uuid,'» ',itm.ptr) for itm in scat_data.uuids_repository] if scat_data.uuids_repository else print('Empty'); print('')"
            
            col.separator(factor=0.5)
            col.operator("scatter5.exec_line", text="Cleanup unused uuid's slots", icon="TOOL_SETTINGS",).api = "scat_data.uuids_repository_cleanup()"
            
            col.separator(factor=0.5)
            col.operator("scatter5.exec_line", text="Print `overseer.Observer` infos", icon="TOOL_SETTINGS",).api = "from .. handlers.overseer import Observer ; Observer.debug_print()"
            
            ui_templates.separator_box_in(box)

    return None




#    .oooooo.   oooo
#   d8P'  `Y8b  `888
#  888           888   .oooo.    .oooo.o  .oooo.o  .ooooo.   .oooo.o
#  888           888  `P  )88b  d88(  "8 d88(  "8 d88' `88b d88(  "8
#  888           888   .oP"888  `"Y88b.  `"Y88b.  888ooo888 `"Y88b.
#  `88b    ooo   888  d8(  888  o.  )88b o.  )88b 888    .o o.  )88b
#   `Y8bood8P'  o888o `Y888""8o 8""888P' 8""888P' `Y8bod8P' 8""888P'


classes = (
    
    SCATTER5_OT_impost_addonprefs,

    )


#if __name__ == "__main__":
#    register()